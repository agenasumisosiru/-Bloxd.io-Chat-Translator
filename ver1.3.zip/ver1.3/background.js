// 初期設定
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({
        enabled: true,
        targetLang: "ja"
    });
});

// アイコンをクリックしたら ON/OFF 切り替え
chrome.action.onClicked.addListener(() => {
    chrome.storage.local.get("enabled", ({ enabled }) => {
        const newState = !enabled;

        chrome.storage.local.set({ enabled: newState }, () => {
            chrome.action.setBadgeText({ text: newState ? "ON" : "OFF" });
            chrome.action.setBadgeBackgroundColor({ color: newState ? "#00C853" : "#D50000" });
        });
    });
});

// 翻訳API
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "translate") {
        chrome.storage.local.get("targetLang", ({ targetLang }) => {
            const tl = targetLang || "ja";
            const sl = "auto";
            const q = encodeURIComponent(msg.text);

            const url =
                `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${tl}&dt=t&dt=bd&dj=1&q=${q}`;

            fetch(url)
                .then(res => res.json())
                .then(data => {
                    const translated = data.sentences.map(s => s.trans).join("");
                    sendResponse(translated);
                })
                .catch(() => sendResponse(null));
        });

        return true;
    }
});

let translateEnabled = true;

chrome.storage.local.get("enabled", ({ enabled }) => {
    translateEnabled = enabled ?? true;
});

chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled) {
        translateEnabled = changes.enabled.newValue;
    }
});

(function waitForGame() {
    const timer = setInterval(() => {
        const game = window.game;
        if (!game || !game.chat || !game.chat.sendMessage) return;

        clearInterval(timer);

        const originalSend = game.chat.sendMessage;

        game.chat.sendMessage = function (text) {

            // 送信は即時（遅延ゼロ）
            originalSend.call(game.chat, text);

            // 翻訳はバックグラウンドで実行
            if (!translateEnabled) return;

            chrome.runtime.sendMessage(
                { type: "translate", text },
                (translated) => {
                    if (!translated) return;

                    const chatMessages = document.querySelector(".Chat .ChatMessages");
                    if (!chatMessages || !chatMessages.lastChild) return;

                    const translatedNode = document.createElement("div");
                    translatedNode.style.color = "#00cc66";
                    translatedNode.style.fontSize = "12px";
                    translatedNode.innerText = `[翻訳] ${translated}`;

                    chatMessages.lastChild.appendChild(translatedNode);
                }
            );
        };

    }, 500);
})();

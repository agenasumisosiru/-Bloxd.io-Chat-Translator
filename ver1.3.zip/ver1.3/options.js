const select = document.getElementById("langSelect");
const toggleBtn = document.getElementById("toggleBtn");

// 言語読み込み
chrome.storage.local.get("targetLang", ({ targetLang }) => {
    select.value = targetLang || "ja";
});

// 言語変更
select.addEventListener("change", () => {
    chrome.storage.local.set({ targetLang: select.value });
});

// ON/OFF 状態読み込み
chrome.storage.local.get("enabled", ({ enabled }) => {
    updateButton(enabled);
});

// ボタン表示更新
function updateButton(state) {
    toggleBtn.textContent = state ? "翻訳 ON" : "翻訳 OFF";
    toggleBtn.style.background = state ? "#00C853" : "#D50000";
    toggleBtn.style.color = "white";
}

// ON/OFF 切り替え
toggleBtn.addEventListener("click", () => {
    chrome.storage.local.get("enabled", ({ enabled }) => {
        const newState = !enabled;
        chrome.storage.local.set({ enabled: newState });
        updateButton(newState);
    });
});
